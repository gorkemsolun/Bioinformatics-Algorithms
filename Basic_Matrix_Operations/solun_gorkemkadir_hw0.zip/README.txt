Görkem Kadir Solun 22003214 HW 0 CS481 kadir.solun@ug.bilkent.edu.tr 

To prepare the executable: make
To clean the executable: make clean
To run the executable: ./basic_matrix_operations -n <size> -s <scalar>
